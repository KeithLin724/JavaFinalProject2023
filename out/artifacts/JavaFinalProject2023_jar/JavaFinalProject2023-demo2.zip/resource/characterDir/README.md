# about the load file 

```
../../res/mainCharacter/ <- this is a path 
5 6 <- characterStateNum , frameNumber
0 0 35 <- aniTick, aniIndex , aniSpeed 
0 0 10 <- imgScaleX, imgScaleY , imgScale
5.0f <- playSpeed
```