# Skin folder 

---

```
skin1.png
```

---

## How to load ?

write a file about the skin list 

format like this 

```
{skin1}
{skin2}
...
```
no file .png name 